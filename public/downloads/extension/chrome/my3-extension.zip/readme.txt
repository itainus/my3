1) open chrome browser
2) go to: chrome://extensions/
3) extract my3.crx to your desktop
3.1) drag & drop my3.crx from your desktop into chrome extensions tab 
4) press on Add button
5) you should have an icon of aback tree on the trop corner of the browser
6) use it to add links to your my tree
* you must be logged in to your my3 account at http://my-3.herokuapp.com/ in order to use the extension
